
#include "StudentWorld.h" 
#include "Actor.h"

StudentWorld:: StudentWorld (std::string assetDir) : GameWorld(assetDir) {
    
}

StudentWorld* StudentWorld:: getStudentWorld() {
    return this;
}

GameWorld* createStudentWorld(string assetDir)
{
    return new StudentWorld(assetDir);
}

StudentWorld::~StudentWorld(){
    list<Base*>::iterator it = AssetList.begin();
    while (it != AssetList.end()) {
        Base* b = *it;
        delete b;
        AssetList.erase(it);
        it++;
    }
}

int StudentWorld:: init () {
    /*
        A. Initialize the data structures used to keep track of your game’s world.
        B. Load the current maze details from a level data file.
        C. Allocate and insert a valid Player object into the game world.
        D. Allocate and insert any SnarlBots objects, Wall objects, Boulder objects, Factory
         objects, Jewel objects, Goodie objects, or Exit objects into the game world, as required by the specification in the current level’s data file.
        */
    string curLevel = "level00.dat";
    Level lev(assetDirectory());
    Level::LoadResult result = lev.loadLevel(curLevel);
    if (result == Level::load_fail_file_not_found) {
        cerr << curLevel << "not found!";
        return GWSTATUS_LEVEL_ERROR;
    }
    else if (result == Level:: load_fail_bad_format) {
        cerr << curLevel << " bad format!";
        return GWSTATUS_LEVEL_ERROR;
    }
    else if (result == Level:: load_success) {
        cerr << curLevel << " loaded successfully.";
        for (int i = 0; i < VIEW_HEIGHT; i++) {
            for (int j = 0; j < VIEW_WIDTH; j++) {
                Level::MazeEntry item = lev.getContentsOf(i, j);
                switch (item) {
                    case Level::player:
                    {
                        Player *p = new Player (IID_PLAYER, i, j, Base::right, this);
                        AssetList.push_back(p);
                        break;
                    }
                    case Level::wall:
                    {
                        Wall *w = new Wall (IID_WALL, i ,j, Base::none, this);
                        AssetList.push_back(w);
                        break;
                    }
                    case Level::empty:
                    case Level::exit:
                    case Level::horiz_snarlbot:
                    case Level::vert_snarlbot:
                    case Level::kleptobot_factory:
                    case Level::angry_kleptobot_factory:
                    case Level::boulder:
                    case Level::hole:
                    case Level::jewel:
                    case Level::extra_life:
                    case Level::restore_health:
                    case Level::ammo:
                    default:
                        break;
                }
            }
        }
    }
    return GWSTATUS_CONTINUE_GAME;
}

int StudentWorld:: move() {
    list<Base*>::iterator it = AssetList.begin();
    while (it != AssetList.end()) {
        Base *b = *it;
        b->doSomething();
        it++;
    }
    return GWSTATUS_CONTINUE_GAME;
}

void StudentWorld:: cleanUp() {
    list<Base*>::iterator it = AssetList.begin();
    while (it != AssetList.end()) {
        Base* b = *it;
        delete b;
        AssetList.erase(it);
        it++;
    }
}

void StudentWorld:: updateDisplayText () {}
    
Base* StudentWorld:: getObject(int x, int y) {
    list<Base*>::iterator it = AssetList.begin();
    while (it != AssetList.end()) {
        Base *b = *it;
        if (b->getX() == x && b->getY() == y) {
            return b;
        }
        it++;
    }
    return nullptr;
}
