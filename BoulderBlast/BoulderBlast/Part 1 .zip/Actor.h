#ifndef ACTOR_H_
#define ACTOR_H_

#include "GraphObject.h"
#include "GameConstants.h"
#include "GameWorld.h"
#include "StudentWorld.h"

// Students:  Add code to this file, Actor.cpp, StudentWorld.h, and StudentWorld.cpp
class Base : public GraphObject {
public:
    Base (int IID, int x, int y, Direction dir, StudentWorld *studWorld);
    virtual void doSomething() = 0;
    bool isAlive ();
    void setAliveorDead (bool alive);
    StudentWorld* getWorld();
private:
//    int m_IID;
//    Direction m_dir;
    bool m_alive;
    StudentWorld* m_world;
};

class Actor : public Base {
public:
    Actor (int IID, int x, int y, Direction dir, StudentWorld *studWorld);
    int getHealth ();
    void setHealth (int hp);
    int getAmmo ();
    void setAmmo (int ammo);
    virtual void doSomething () = 0;
private:
    int m_health;
    int m_ammo;
    
};

class Object : public Base {
public:
    Object (int IID, int x, int y, Direction dir, StudentWorld *studWorld);
    virtual void doSomething () = 0;
};

class Player : public Actor {
public:
    Player (int IID, int x, int y, Direction dir, StudentWorld *studWorld);
    virtual void doSomething ();
};

class SnarlBot : Actor {
    
};

class HorizontalSnarlBot : SnarlBot {
    
};

class VerticalSnarlBot : SnarlBot {
    
};

class KleptoBot : Actor {
    
};

class AngryKleptoBot: KleptoBot {
    
};


class Factory : Object {
    
};

class RegularFactory : Factory {
    
};

class AngryFactory : Factory {
    
};

class Bullet : Object {
    
};

class Exit : Object {
    
};

class Wall : public Object {
public:
    Wall (int IID, int x, int y, Direction dir, StudentWorld *studWorld);
    virtual void doSomething();
};

class Boulder : Actor {
    
};

class Hole : Object {
    
};

class Jewel : Object {
    
};

class Goody : Object {
    
};

class RestoreHealthGoody : Goody {
    
};

class ExtraLifeGoody : Goody {
    
};

class AmmoGoody : Goody {
    
};

/* 
 The Player’s avatar
 • SnarlBots (Horizontal and Vertical varieties)
 • KleptoBots
 • Angry KleptoBots
 • Factories (for Regular and Angry KleptoBots)
 • Bullets (that can be shot by both the Player and robots)
 • The Exit for the level
 • Walls
 • Boulders
 • Holes
 • Jewels
 • Restore Health Goodies
 • Extra Life Goodies
 • Ammo Goodies
*/





#endif // ACTOR_H_
