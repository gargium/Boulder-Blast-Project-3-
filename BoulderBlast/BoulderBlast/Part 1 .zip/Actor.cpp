#include "Actor.h"
#include "GameConstants.h"

// Students:  Add code to this file (if you wish), Actor.h, StudentWorld.h, and StudentWorld.cpp

///////////////////////////////////////////////
//////////CONSTRUCTOR IMPLEMENTATIONS//////////
///////////////////////////////////////////////

Base:: Base (int IID, int x, int y, Direction dir, StudentWorld *studWorld) : GraphObject (IID, x, y, dir), m_world(studWorld) {
//    m_IID = IID;
//    m_dir = dir;
    setVisible(true);
}

Actor:: Actor (int IID, int x, int y, Direction dir, StudentWorld *studWorld) : Base (IID, x, y, dir, studWorld) {
    
}

Object:: Object (int IID, int x, int y, Direction dir, StudentWorld *studWorld) : Base(IID, x, y, dir, studWorld) {
    
}

Player:: Player (int IID, int x, int y, Direction dir, StudentWorld *studWorld) : Actor(IID = IID_PLAYER, x , y, dir = right, studWorld) {
        setHealth(20);
        setAmmo(20);
}

Wall:: Wall (int IID, int x, int y, Direction dir, StudentWorld *studWorld) : Object(IID = IID_WALL, x, y, dir = none, studWorld) {
}

//////////////////////////////////////////////
//////////BASE MEMBER FUNCTIONS///////////////
//////////////////////////////////////////////
void Base:: setAliveorDead(bool isAlive) {
    m_alive = isAlive;
}

bool Base:: isAlive() {
    return m_alive;
}

StudentWorld* Base:: getWorld() {
   // StudentWorld *sw = new StudentWorld("");
  //  return sw->getStudentWorld();
    return m_world;
}
//////////////////////////////////////////////
//////////WALL MEMBER FUNCTIONS//////////////
//////////////////////////////////////////////
void Wall:: doSomething() {
    return;
}

//////////////////////////////////////////////
//////////ACTOR MEMBER FUNCTIONS//////////////
//////////////////////////////////////////////
int Actor::getHealth() {
    return m_health;
}

void Actor::setHealth (int hp) {
    m_health = hp;
}

int Actor::getAmmo () {
    return m_ammo;
}

void Actor::setAmmo (int ammo) {
    m_ammo = ammo;
}
//////////////////////////////////////////////
//////////PLAYER MEMBER FUNCTIONS/////////////
//////////////////////////////////////////////
void Player::doSomething() {
        int ch;
        if (getWorld()->getKey(ch)) {
            switch (ch) {
                case KEY_PRESS_ESCAPE:
                    break;
                case KEY_PRESS_SPACE:
                    break;
                case KEY_PRESS_DOWN:
                    //if there is a wall, dont move.
                    if(getWorld()->getObject(getX(), getY()-1) == nullptr)
                        moveTo(getX(), getY()-1);
                    setDirection(down);
                    break;
                case KEY_PRESS_UP:
                    if(getWorld()->getObject(getX(), getY()+1) == nullptr)
                        moveTo(getX(), getY()+1);
                    setDirection(up);
                    break;
                case KEY_PRESS_LEFT:
                    if(getWorld()->getObject(getX()-1, getY()) == nullptr)
                        moveTo(getX()-1, getY());
                    setDirection(left);
                    break;
                case KEY_PRESS_RIGHT:
                    if (getWorld()->getObject(getX()+1, getY()) == nullptr)
                        moveTo(getX()+1, getY());
                    setDirection(right);
                    break;
                default:
                    break;
       }
    }
}
